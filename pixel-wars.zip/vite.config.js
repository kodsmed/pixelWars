export default {
  root: 'src',
  build: {
    outDir: '../dist',
    target: 'esnext'
  }
}
