import './jk224jv-pixel-wars.js'
