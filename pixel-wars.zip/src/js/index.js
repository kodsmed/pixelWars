/**
 * The main script file of the application.
 *
 * @author Jimmy Karlsson <jk224jv@student.lnu.se>
 * @version 1.1.0
 */

import './components/jk224jv-pixel-wars/index.js'
